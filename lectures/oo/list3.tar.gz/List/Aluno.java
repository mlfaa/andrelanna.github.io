package Colecoes.List;

public class Aluno implements Comparable<Aluno>{
	String nome; 
	int matricula;
	String curso;
	
	public Aluno() {
		
	}
	
	Aluno(String n, int m, String c) {
		nome = n;
		matricula = m;
		curso = c;
	}
	
	@Override
	public int compareTo(Aluno o) {
		//Ordenar por numero de matricula
		if (matricula < o.matricula)
			return -1;
		else if (matricula > o.matricula)
			return 1;
		else 
		return 0;
	}
	
}
