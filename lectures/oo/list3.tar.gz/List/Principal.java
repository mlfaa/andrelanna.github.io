package Colecoes.List;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Principal {
	public static void main(String[] args) {

		List<Aluno> turma; // turma é uma referência para uma lista de alunos

		turma = new LinkedList<Aluno>(); // a lista de alunos é representada por
											// um objeto da classe LinkedList

		// Criam-se quantos alunos forem necessarios, no caso 3.
		Aluno a = new Aluno("Andre", 13, "Engenharia de Software");
		Aluno b = new Aluno("Maria", 27, "Matematica");
		Aluno c = new Aluno("Cinthia", 20, "Direito");

		// Adicionam-se os alunos à turma pela simples chamada ao método add.
		turma.add(a);
		turma.add(b);
		turma.add(c);

		// Ordenando os elementos da turma pelo numero de matricula
		Collections.sort(turma);
		imprimirTurma(turma);
		// Pergunta: como ele sabe/realiza a ordenação por esse atributo
		// (matricula)?

		// Removendo um aluno pela posicão ocupada na lista
		Aluno removido = turma.remove(1);
		if (removido != null) {
			System.out.println("----Aluno removido: " + removido.nome);
		}
	}

	private static void imprimirTurma(List<Aluno> turma) {
		for (Aluno al : turma) {
			String descricaoAluno = "\n---" + "\nPosicao: " + turma.indexOf(al)
					+ "\nNome: " + al.nome + "\nMatricula: " + al.matricula
					+ "\nCurso: " + al.curso;
			System.out.println(descricaoAluno);
		}
	}
}
