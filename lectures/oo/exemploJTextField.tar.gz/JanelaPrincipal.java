package introducaoSwing;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class JanelaPrincipal extends JFrame{
	JTextField txtField;
	
	public JanelaPrincipal() {
		this.setTitle("Aula 1 - Introdução a Swing em Java");
		this.setSize(200, 50);
		
		txtField = new JTextField("Isso é um campo de texto!!!");
		
		add(txtField);
		
		this.setVisible(true);
	}
}
