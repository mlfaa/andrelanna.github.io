

class Bicicleta {
	String marca; 
	String modelo; 
	String cor; 
	int marchas;
	int velocidade;

	//vou definir o meu construtor padrao
	Bicicleta() {
		marca = "nao definida";
		modelo = "nao definido";
		cor = "nao definida";
		marchas = 0;
		velocidade = -1;
	}	

	//vou definir o meu construtor alternativo
	Bicicleta(String mar, String mod, String c, int m, int v) {
		marca = mar;
		modelo = mod;
		cor = c;
		marchas = m;
		velocidade = v;
	}

}
