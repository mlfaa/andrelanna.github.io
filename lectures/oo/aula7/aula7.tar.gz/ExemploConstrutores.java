

class ExemploConstrutores {
	
	public static void main (String[] args) {
		Bicicleta bic1, 
			  bic2, 
			  bic3, 
			  bic4;


		//chamada ao construtor padrao, para inst. objeto.
		bic3 = bic4 = new Bicicleta("Trek", "bleh", "branca", 21, 30);
	
		System.out.println("Marca: " + bic4.marca + '\n' + 
				   "Modelo: " + bic4.modelo + '\n' + 
				   "Qtde marchas: " + bic4.marchas + '\n' + 
				   "Cor: " + bic4.cor + '\n' + 
				   "Velocidade: " + bic4.velocidade);

		bic3.marca = "Monark";
		bic3.modelo = "barra circular";
		bic3.marchas = 1;
		bic3.cor = "Azul";
		bic3.velocidade = 0;

		System.out.println("Marca: " + bic4.marca + '\n' + 
				   "Modelo: " + bic4.modelo + '\n' + 
				   "Qtde marchas: " + bic4.marchas + '\n' + 
				   "Cor: " + bic4.cor + '\n' + 
				   "Velocidade: " + bic4.velocidade);
	}

}
