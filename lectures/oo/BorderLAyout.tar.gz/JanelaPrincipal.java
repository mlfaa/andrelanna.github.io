package introducaoSwing;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;

public class JanelaPrincipal extends JFrame { // Uma classe que gera uma
												// interface gráfica deve
												// extender a classe JFrame da
												// biblioteca Swing.

	JCheckBox chkBox;

	public JanelaPrincipal() { // metodo construtor da classe JanelaPrincipal

		// Definindo as características visíveis da interface gráfica
		setTitle("Aula 1 - Introdução a Swing em Java"); // Titulo da janela
		setSize(500, 500); // Dimensoes da janela em pixels
		setLocation(100, 100); // Posicao que a janela vai aparecer no monitor
		setMinimumSize(new Dimension(50, 50)); // Dimensoes minimas da janela
		setMaximumSize(new Dimension(500, 500)); // Dimensoes maximas da janela
		setLayout(new BorderLayout()); // Gerenciador de layout do tipo FlowLayout

		//Elementos a serem adicionados no Layout
		JButton btnTop = new JButton("Botao @Norte"),
		 		btnBottom = new JButton("Botao @Sul"), 
		 		btnLeft = new JButton("Botao @Oeste"),
		 		btnRight = new JButton("Botao @Leste"),
		 		btnCenter = new JButton("Botao @Centro");

		
		//Adicionar os botões em cada posição da interface
		add(btnTop, BorderLayout.NORTH);
		add(btnBottom, BorderLayout.SOUTH);
		add(btnLeft, BorderLayout.WEST);
		add(btnRight, BorderLayout.EAST);
		add(btnCenter, BorderLayout.CENTER);
		
		// Torna a janela visivel no monitor
		setVisible(true);
	}
}
