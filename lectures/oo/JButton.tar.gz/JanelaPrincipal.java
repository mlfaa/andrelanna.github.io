package introducaoSwing;

import javax.swing.JButton;
import javax.swing.JFrame;

public class JanelaPrincipal extends JFrame{
	JButton btnOk,
	        btnCancel;
	
	public JanelaPrincipal() {
		this.setTitle("Aula 1 - Introdução a Swing em Java");
		this.setSize(200, 50);
		
		btnOk = new JButton("Ok");
		btnCancel = new JButton("Cancel");
		
		add(btnOk);
		add(btnCancel);
		
		this.setVisible(true);
	}
}
