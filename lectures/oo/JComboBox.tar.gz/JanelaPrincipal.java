package introducaoSwing;

import java.awt.Dimension;

import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class JanelaPrincipal extends JFrame { // Uma classe que gera uma
												// interface gráfica deve
												// extender a classe JFrame da
												// biblioteca Swing.

	JComboBox cmbBox;

	public JanelaPrincipal() { // metodo construtor da classe JanelaPrincipal

		// Definindo as características visíveis da interface gráfica
		setTitle("Aula 1 - Introdução a Swing em Java"); // Titulo da janela
		setSize(200, 50); // Dimensoes da janela em pixels
		setLocation(100, 100); // Posicao que a janela vai aparecer no monitor
		setMinimumSize(new Dimension(50, 50)); // Dimensoes minimas da janela
		setMaximumSize(new Dimension(300, 300)); // Dimensoes maximas da janela

		cmbBox = new JComboBox();
		cmbBox.addItem("Item 1"); // Adiciona uma String ao comboBox
		cmbBox.addItem("Item 2"); // Adiciona uma String ao comboBox
		cmbBox.addItem("Item 3"); // Adiciona uma String ao comboBox
		cmbBox.addItem("Item 4"); // Adiciona uma String ao comboBox

		Object ob = cmbBox.getSelectedItem(); // Retorna o elemento do comboBox
												// que está selecionado no
												// momento

		int qteElementos = cmbBox.getItemCount(); // Informa o numero de
													// elementos presentes na
													// lista

		cmbBox.setEnabled(true);

		add(cmbBox);

		// Torna a janela visivel no monitor
		setVisible(true);
	}
}
