package introducaoSwing;

public class Principal {

	static JanelaPrincipal janela;
	
	public static void main(String[] args) {
		janela = new JanelaPrincipal();

	}

}
