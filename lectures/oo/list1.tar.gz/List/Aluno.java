package Colecoes.List;

public class Aluno {
	String nome; 
	int matricula;
	String curso;
	
	public Aluno() {
		
	}
	
	Aluno(String n, int m, String c) {
		nome = n;
		matricula = m;
		curso = c;
	}
	
}
