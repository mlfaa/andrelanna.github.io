package Colecoes.List;

import java.util.LinkedList;
import java.util.List;

public class Principal {
	public static void main(String[] args) {

		List<Aluno> turma; // turma é uma referência para uma lista de alunos

		turma = new LinkedList<Aluno>(); // a lista de alunos é representada por
											// um objeto da classe LinkedList

		// Criam-se quantos alunos forem necessarios, no caso 3.
		Aluno a = new Aluno("Andre", 13, "Engenharia de Software");
		Aluno b = new Aluno("Maria", 27, "Matematica");
		Aluno c = new Aluno("Cinthia", 20, "Direito");

		// Adicionam-se os alunos à turma pela simples chamada ao método add.
		turma.add(a);
		turma.add(b);
		turma.add(c);

		// Quantos alunos possui a turma?
		System.out.println("# alunos: " + turma.size());
		
		//Quais são esses alunos?
		for (Aluno al : turma) {
			String descricaoAluno = "\n---" 
					+ "\nNome: " + al.nome 
					+ "\nMatricula: " + al.matricula  
					+ "\nCurso: " + al.curso; 
			System.out.println(descricaoAluno);
		}
	}
}
