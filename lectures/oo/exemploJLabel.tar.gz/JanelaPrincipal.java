package introducaoSwing;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class JanelaPrincipal extends JFrame{
	JLabel lblUniversidade;
	JLabel lblFaculdade;
	JLabel lblCurso;
	JLabel lblDisciplina;
	JLabel lblProfessor;
	
	public JanelaPrincipal() {
		this.setTitle("Aula 1 - Introdução a Swing em Java");
		this.setSize(200, 50);
		
		lblUniversidade = new JLabel("UnB - Universidade de Brasilia");
		lblFaculdade = new JLabel("FGA - Faculdade do Gama");
		lblCurso = new JLabel("ESW - Engenharia de Software");
		lblDisciplina = new JLabel("OO - Orientação por Objetos");
		lblProfessor = new JLabel("André Luiz Peron Martins Lanna");
		
		this.add(lblUniversidade);
		this.add(lblFaculdade);
		this.add(lblCurso);
		this.add(lblDisciplina);
		this.add(lblProfessor);
		
		this.setVisible(true);
	}
}
