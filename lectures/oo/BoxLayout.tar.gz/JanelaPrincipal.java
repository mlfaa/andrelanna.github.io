package introducaoSwing;

import java.awt.Dimension;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class JanelaPrincipal extends JFrame { // Uma classe que gera uma
												// interface gráfica deve
												// extender a classe JFrame da
												// biblioteca Swing.

	JCheckBox chkBox;

	public JanelaPrincipal() { // metodo construtor da classe JanelaPrincipal

		// Definindo as características visíveis da interface gráfica
		setTitle("Aula 1 - Introdução a Swing em Java"); // Titulo da janela
		setSize(500, 500); // Dimensoes da janela em pixels
		setLocation(100, 100); // Posicao que a janela vai aparecer no monitor
		setMinimumSize(new Dimension(50, 50)); // Dimensoes minimas da janela
		setMaximumSize(new Dimension(500, 500)); // Dimensoes maximas da janela
		JPanel panel = new JPanel();
		
		setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
//		setLayout(new BoxLayout(getContentPane(), BoxLayout.X_AXIS));
		
		//Elementos a serem adicionados no Layout
		JButton btn1 = new JButton("Botao 1"),
		 		btn2 = new JButton("Botao 2"), 
		 		btn3 = new JButton("Botao 3"),
		 		btn4 = new JButton("Botao 4"),
		 		btn5 = new JButton("Botao 5");

		
		//Adicionar os botões em cada posição da interface
		add(btn1);
		add(btn2);
		add(btn3);
		add(btn4);
		add(btn5);
		
		// Torna a janela visivel no monitor
		setVisible(true);
	}
}
