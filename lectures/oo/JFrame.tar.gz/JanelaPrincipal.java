package introducaoSwing;

import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JTextField;

public class JanelaPrincipal extends JFrame { // Uma classe que gera uma
												// interface gráfica deve
												// extender a classe JFrame da
												// biblioteca Swing.

	public JanelaPrincipal() { // metodo construtor da classe JanelaPrincipal

		// Definindo as características visíveis da interface gráfica
		setTitle("Aula 1 - Introdução a Swing em Java"); // Titulo da janela
		setSize(200, 50); // Dimensoes da janela em pixels
		setLocation(100, 100); // Posicao que a janela vai aparecer no monitor
		setMinimumSize(new Dimension(50, 50)); // Dimensoes minimas da janela
		setMaximumSize(new Dimension(300, 300)); // Dimensoes maximas da janela

		//Torna a janela visivel no monitor
		this.setVisible(true);
	}
}
