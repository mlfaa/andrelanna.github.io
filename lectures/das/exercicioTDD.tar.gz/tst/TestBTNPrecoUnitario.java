import static org.junit.Assert.assertEquals;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;


@RunWith(Parameterized.class)
public class TestBTNPrecoUnitario {

	BTN btn; 
	float pAnt;
	float expected;
	
	public TestBTNPrecoUnitario(float pAnt, float expected) {
		this.pAnt = pAnt;
		this.expected = expected;
	}
	
	@Parameters
	public static Iterable dados() {
		 return Arrays.asList(new Object[][]{
				 {1.0f, 0.076400f}, 
				 {2.0f, 0.152800f},
				 {2.5f, 0.191000f}
		 });
	}
	
	@Before
	public void setUp() throws Exception {
		btn = new BTN(pAnt);
	}

	@Test
	public void testPrecoUnitario() {
		assertEquals(expected, btn.getPrecoUnitario(), 0.000001f);
	}
}
