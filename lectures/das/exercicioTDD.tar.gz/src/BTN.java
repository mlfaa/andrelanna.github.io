
public class BTN {

	private float tr = 0.076400f;
	private float puAnt;
	
	public BTN(float puAnt) {
		this.puAnt = puAnt;
	}

	public float getPrecoUnitario() {
		return tr * puAnt;
	}

}
